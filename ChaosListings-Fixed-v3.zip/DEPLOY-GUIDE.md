# ChaosListings - Quick Deploy Guide

## The Problem
You deployed frontend to Netlify, but there's no backend for it to talk to.
Frontend → calls → Backend API → calls → Database

## The Solution (15 minutes)

### Step 1: Deploy Backend to Railway (Free)

1. Go to [railway.app](https://railway.app)
2. Sign in with GitHub
3. Click "New Project" → "Deploy from GitHub repo"
4. Select your `ChaosListings` repo
5. Railway will auto-detect the `backend` folder

**Set these environment variables in Railway:**
```
NODE_ENV=production
PORT=3000

# Database - Railway provides this automatically if you add PostgreSQL
DATABASE_URL=<auto-filled by Railway>

# Redis - Add Redis service in Railway, it auto-fills
REDIS_HOST=<auto-filled>
REDIS_PORT=6379
REDIS_PASSWORD=<auto-filled>
REDIS_TLS=true

# JWT - Generate a random string
JWT_SECRET=<generate-64-char-random-string>
JWT_EXPIRY=24h
JWT_REFRESH_EXPIRY=7d

# Frontend URL (your Netlify URL)
FRONTEND_URL=https://your-app.netlify.app
```

6. Add PostgreSQL: Click "New" → "Database" → "PostgreSQL"
7. Add Redis: Click "New" → "Database" → "Redis"
8. Railway will give you a URL like: `https://chaoslistings-backend.railway.app`

### Step 2: Configure Netlify Frontend

1. Go to Netlify → Your site → Site settings → Environment variables
2. Add:
```
NEXT_PUBLIC_API_URL=https://your-backend.railway.app/api/v1
```
3. Trigger a redeploy

### Step 3: Initialize Database

In Railway, open the backend service shell:
```bash
npx prisma migrate deploy
npx prisma db seed
```

### Step 4: Test

1. Go to your Netlify URL
2. Click Register
3. It should work!

---

## Alternative: Run Everything Locally First

If you want to test before deploying:

### Terminal 1 - Database (Docker)
```bash
docker run -d --name postgres -e POSTGRES_PASSWORD=password -p 5432:5432 postgres:14
docker run -d --name redis -p 6379:6379 redis:7-alpine
```

### Terminal 2 - Backend
```bash
cd backend
cp .env.example .env
# Edit .env with: DATABASE_URL=postgresql://postgres:password@localhost:5432/postgres
npm install
npx prisma migrate dev
npx prisma db seed
npm run start:dev
```

### Terminal 3 - Frontend
```bash
cd frontend
npm install
npm run dev
```

Open http://localhost:3001

---

## Common Errors

**"Network Error" on register**
- Backend not running or wrong URL
- Check NEXT_PUBLIC_API_URL includes `/api/v1`

**"CORS Error"**  
- Backend FRONTEND_URL doesn't match your actual frontend URL
- Update FRONTEND_URL in backend .env

**"Database connection failed"**
- DATABASE_URL is wrong
- Database not running

**"Redis connection failed"**
- REDIS_HOST/PORT wrong
- Redis not running
