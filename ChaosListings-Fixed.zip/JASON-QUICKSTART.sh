#!/bin/bash
# =====================================================
# ChaosListings Quickstart - For Jason
# Run this on your local Windows machine (Git Bash or WSL)
# =====================================================

echo "╔═══════════════════════════════════════════════════╗"
echo "║   ChaosListings - Local Development Setup         ║"
echo "╚═══════════════════════════════════════════════════╝"
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check prerequisites
echo -e "${YELLOW}Checking prerequisites...${NC}"

if ! command -v node &> /dev/null; then
    echo -e "${RED}❌ Node.js not found. Install from: https://nodejs.org${NC}"
    exit 1
fi

NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 18 ]; then
    echo -e "${RED}❌ Node.js 18+ required. You have $(node -v)${NC}"
    exit 1
fi
echo -e "${GREEN}✅ Node.js $(node -v)${NC}"

if ! command -v npm &> /dev/null; then
    echo -e "${RED}❌ npm not found${NC}"
    exit 1
fi
echo -e "${GREEN}✅ npm $(npm -v)${NC}"

echo ""
echo "=====================================================>"
echo "STEP 1: Install Backend Dependencies"
echo "=====================================================>"
cd backend
npm install
if [ $? -ne 0 ]; then
    echo -e "${RED}❌ Backend npm install failed${NC}"
    exit 1
fi
echo -e "${GREEN}✅ Backend dependencies installed${NC}"

echo ""
echo "=====================================================>"
echo "STEP 2: Check .env file"
echo "=====================================================>"
if [ ! -f ".env" ]; then
    echo -e "${YELLOW}⚠️  No .env file found. Creating from template...${NC}"
    cp .env.example .env
    echo -e "${YELLOW}📝 IMPORTANT: Edit backend/.env with your credentials:${NC}"
    echo "   - DATABASE_URL (get free DB from supabase.com)"
    echo "   - REDIS_HOST/PASSWORD (get free Redis from upstash.com)"
    echo "   - JWT_SECRET (generate a random string)"
    echo ""
    echo -e "${RED}Press Enter after you've edited the .env file...${NC}"
    read
fi
echo -e "${GREEN}✅ .env file exists${NC}"

echo ""
echo "=====================================================>"
echo "STEP 3: Generate Prisma Client"
echo "=====================================================>"
npx prisma generate
if [ $? -ne 0 ]; then
    echo -e "${RED}❌ Prisma generate failed${NC}"
    exit 1
fi
echo -e "${GREEN}✅ Prisma client generated${NC}"

echo ""
echo "=====================================================>"
echo "STEP 4: Run Database Migrations"
echo "=====================================================>"
npx prisma migrate deploy
if [ $? -ne 0 ]; then
    echo -e "${YELLOW}⚠️  Migration failed - trying dev mode...${NC}"
    npx prisma migrate dev --name init
fi
echo -e "${GREEN}✅ Database migrated${NC}"

echo ""
echo "=====================================================>"
echo "STEP 5: Seed Database"
echo "=====================================================>"
npx prisma db seed
if [ $? -ne 0 ]; then
    echo -e "${YELLOW}⚠️  Seed failed (may already be seeded)${NC}"
fi
echo -e "${GREEN}✅ Database seeded${NC}"

echo ""
echo "=====================================================>"
echo "STEP 6: Install Frontend Dependencies"
echo "=====================================================>"
cd ../frontend
npm install
if [ $? -ne 0 ]; then
    echo -e "${RED}❌ Frontend npm install failed${NC}"
    exit 1
fi
echo -e "${GREEN}✅ Frontend dependencies installed${NC}"

echo ""
echo "╔═══════════════════════════════════════════════════╗"
echo "║   ✅ SETUP COMPLETE!                              ║"
echo "╚═══════════════════════════════════════════════════╝"
echo ""
echo "To start the application:"
echo ""
echo "  Terminal 1 (Backend):"
echo "    cd backend && npm run start:dev"
echo ""
echo "  Terminal 2 (Workers):"  
echo "    cd backend && npm run worker:dev"
echo ""
echo "  Terminal 3 (Frontend):"
echo "    cd frontend && npm run dev"
echo ""
echo "Then open: http://localhost:3001"
echo "API Docs:  http://localhost:3000/api/docs"
echo ""
echo "First steps:"
echo "  1. Register a new account"
echo "  2. Create a business"
echo "  3. Go to Listings page"
echo "  4. Test the optimization score"
echo ""
